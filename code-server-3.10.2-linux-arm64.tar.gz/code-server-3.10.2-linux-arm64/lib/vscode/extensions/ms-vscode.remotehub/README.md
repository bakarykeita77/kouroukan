# RemoteHub for VS Code

## Features

This extension provides the ability to remotely browse and edit a GitHub repository from within VS Code.
